﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CRUDUsingMVCwithAdoDotNet.Models
{
    public class ProductModel
    {
        [Display(Name = "Id")]

        public int ProductId { get; set; }
        [Required(ErrorMessage = "ProductName is required.")]

        public string ProductName { get; set; }
        public int CategoryId { get; set; }
        [Required(ErrorMessage = "CategoryName is required.")]
        public string CategoryName { get; set; }

    }
}
