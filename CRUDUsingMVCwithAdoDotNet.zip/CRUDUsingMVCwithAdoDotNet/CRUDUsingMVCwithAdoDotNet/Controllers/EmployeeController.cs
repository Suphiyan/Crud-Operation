﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CRUDUsingMVC.Repository;
using CRUDUsingMVCwithAdoDotNet.Models;

namespace CRUDUsingMVC.Controllers
{
   
    public class EmployeeController : Controller
    {
      
       
        // GET: Employee/GetAllEmpDetails
      
        public ActionResult GetAllEmpDetails()
        {
          
            EmpRepository EmpRepo = new EmpRepository();
            ModelState.Clear();
            return View(EmpRepo.GetAllEmployees());
        }


        // GET: Employee/AddEmployee
        public ActionResult AddEmployee()
        {
            return View();
        }

        // POST: Employee/AddEmployee
        [HttpPost]
        public ActionResult AddEmployee(ProductModel Emp)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    EmpRepository EmpRepo = new EmpRepository();

                    if (EmpRepo.AddEmployee(Emp))
                    {
                        ViewBag.Message = "Product details added successfully";
                    }
                }
              
                return RedirectToAction("GetAllEmpDetails");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/EditEmpDetails/5
        public ActionResult EditEmpDetails(int id)
        {
            EmpRepository EmpRepo = new EmpRepository();

          

            return View(EmpRepo.GetAllEmployees().Find(Emp => Emp.ProductId == id));

        }

        // POST: Employee/EditEmpDetails/5
        [HttpPost]
      
        public ActionResult EditEmpDetails(int id, ProductModel obj)
        {
            try
            {
                    EmpRepository EmpRepo = new EmpRepository();
                  
                    EmpRepo.UpdateProduct(obj);
               



                return RedirectToAction("GetAllEmpDetails");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/DeleteEmp/5
        public ActionResult DeleteProducts(int id)
        {
            try
            {
                EmpRepository EmpRepo = new EmpRepository();
                if (EmpRepo.DeleteProduct(id))
                {
                    ViewBag.AlertMsg = "Product details deleted successfully";

                }
                return RedirectToAction("GetAllEmpDetails");

            }
            catch
            {
                return View();
            }
        }

   
    }
}
