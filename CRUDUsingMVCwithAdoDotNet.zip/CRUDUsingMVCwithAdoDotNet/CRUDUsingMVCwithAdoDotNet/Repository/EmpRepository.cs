﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using CRUDUsingMVCwithAdoDotNet.Models;

namespace CRUDUsingMVC.Repository
{
    public class EmpRepository
    {
        private SqlConnection con;
        private void connection()
        {
            string constr = ConfigurationManager.ConnectionStrings["getconn"].ToString();
            con = new SqlConnection(constr);

        }

        public bool AddEmployee(ProductModel obj)
        {

            connection();
            SqlCommand com = new SqlCommand("AddNewProducts", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ProductName", obj.ProductName);
            com.Parameters.AddWithValue("@CategoryId", obj.CategoryId);
            com.Parameters.AddWithValue("@CategoryName", obj.CategoryName);
          
            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {

                return true;

            }
            else
            {

                return false;
            }


        }

        public List<ProductModel> GetAllEmployees()
        {
            connection();
            List<ProductModel> EmpList =new List<ProductModel>();
           

            SqlCommand com = new SqlCommand("GetProducts", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
          
            con.Open();
            da.Fill(dt);
            con.Close();
            foreach (DataRow dr in dt.Rows)
            {

                EmpList.Add(

                    new ProductModel {

                        ProductId = Convert.ToInt32(dr["ProductId"]),
                        ProductName = Convert.ToString( dr["ProductName"]),
                        CategoryId = Convert.ToInt32( dr["CategoryId"]),
                        CategoryName = Convert.ToString(dr["CategoryName"])

                    }
                    
                    
                    );


            }

            return EmpList;


        }

        public bool UpdateProduct(ProductModel obj)
        {

            connection();
            SqlCommand com = new SqlCommand("UpdateProductDetails", con);
           
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ProductId", obj.ProductId);
            com.Parameters.AddWithValue("@ProductName", obj.ProductName);
            com.Parameters.AddWithValue("@CategoryId", obj.CategoryId);
            com.Parameters.AddWithValue("@CategoryName", obj.CategoryName);
            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {
                
                return true;

            }
            else
            {

                return false;
            }


        }
        public bool DeleteProduct(int Id)
        {

            connection();
            SqlCommand com = new SqlCommand("DeleteProductById", con);

            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ProductId", Id);
           
            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {
               
                return true;

            }
            else
            {

                return false;
            }


        }
    }
}